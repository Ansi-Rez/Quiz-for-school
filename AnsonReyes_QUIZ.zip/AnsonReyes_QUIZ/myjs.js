//Fields or variables
let firstName, lastName, accountType, balance;
let appointmentDate = "";
const now = new Date();
//Function that initializes the variables that make up the account
function EBANK(firstName,lastName,accountType,openingBalance)
{
    EBANK.transaction._init(arguments);
}
//The arguments that are passed into the EBANK function are initialized into a variable called args
var args = EBANK.arguments;
//The args variable is then used to pass the EBANK function parameters into the _init function
EBANK.transaction = {
//When this function is called it checks if it was passed four arguments and then sets the variable values
_init:function(args)
{
    if(args.length == 4)
    {
        for(let i = 0; i < args.length; i++)
        {
            switch(i)
            {
                case 0: firstName = args[0];
                break;

                case 1: lastName = args[1];
                break;

                case 2: accountType = args[2];
                break;

                case 3: balance = args[3];
                break;
            }
        }
    }
    else
    {
        console.log("Please enter the required information");
    }
},
//This function allows the user to deposit money into the balance provided they enter the correct information
deposit:function(depos)
{
    if(depos > 0 && typeof(depos) == "number")
    {
        balance += depos;
    }
    else
    {
        console.log("Please enter a positive number amount");
    }
},
//This function allows the user to withdraw money from the balance provided they enter the correct information
withdraw:function(witd)
{
    if(witd <= balance && typeof(witd) == "number" && witd >= 0)
    {
        balance -= witd;
    }
    else
    {
        console.log("Please enter a positive number amount that is equal to or less than your balance");
    }
},
//This function prints the current account balance
getbalance:function()
{
    console.log("Your current balance is: " + balance);
}
}
//I added a new property here to store the two functions not directly related to transaction activity
EBANK.options = {
//This function checks the date you have entered and sets the appointmentDate variable provided you meet one of the requirements
makeAppointment:function(time,day,month,year)
{
    /*The nested if statements check if the year you entered is the current year, if so it checks if the current
    month is less than the month you entered and does the same with the day. If so it means the appointment can
    be set becuase it's 31 or more days into the future. If the year you entered is more than the current year
    then it checks if the current month is less than 11(december) if so the appointment date is set.
    If the current month is 11 and the month you enter is more than 0(january) the appointment date is set.
    If the month entered is january and current month is december then the program checks if 31 days are
    between the current day and the day you entered. If any of these conditions aren't met the function will
    print "Please enter a valid date".Also if you enter a year that is more than one year away the appointment
    is set*/
    if(now.getFullYear() == year && now.getDate <= day && now.getMonth() < month)
    {
        appointmentDate = "hour: " + time + "," + "day of the month: " + day + "," + "month: " + month + "," + "year: " + year;
    }
    else if(now.getFullYear() < year)
    {
        if(now.getFullYear() + 1 < year)
        {
        appointmentDate = "hour: " + time + "," + "day of the month: " + day + "," + "month: " + month + "," + "year: " + year;
        }
        else if(now.getMonth() < 11)
        {
        appointmentDate = "hour: " + time + "," + "day of the month: " + day + "," + "month: " + month + "," + "year: " + year;
        }
        else if(now.getMonth() == 11 && month > 0)
        {
        appointmentDate = "hour: " + time + "," + "day of the month: " + day + "," + "month: " + month + "," + "year: " + year;
        }
        else if(now.getMonth() == 11 && now.getDate() <= day && month == 0)
        {
        appointmentDate = "hour: " + time + "," + "day of the month: " + day + "," + "month: " + month + "," + "year: " + year;
        }
        else
        {
            console.log("Please enter a valid date");
        }
    }
    else
    {
        console.log("Please enter a valid date");
    }
},
//Function prints a summary of account information
accountSummary:function()
{
    console.log("First Name: " + firstName + "\n"
    + "Last Name: " + lastName + "\n"
    + "Account Type: " + accountType + "\n"
    + "Balance: " + balance + "\n"
    + "Appointment Date: " + appointmentDate);
}
}